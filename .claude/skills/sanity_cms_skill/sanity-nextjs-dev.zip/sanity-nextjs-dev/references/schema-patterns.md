# Sanity Schema Design Patterns

Comprehensive guide to creating robust, scalable Sanity schemas with best practices and common patterns.

## Schema Organization

### Directory Structure

```
schemas/
├── index.ts              # Export all schemas
├── documents/            # Document types
│   ├── post.ts
│   ├── author.ts
│   └── category.ts
├── objects/             # Reusable object types
│   ├── blockContent.ts
│   ├── seo.ts
│   └── link.ts
└── singletons/          # Singleton documents
    ├── siteSettings.ts
    └── navigation.ts
```

### Index File Pattern

```typescript
// schemas/index.ts
import { SchemaTypeDefinition } from 'sanity'

// Documents
import { post } from './documents/post'
import { author } from './documents/author'
import { category } from './documents/category'

// Objects
import { blockContent } from './objects/blockContent'
import { seo } from './objects/seo'

// Singletons
import { siteSettings } from './singletons/siteSettings'

export const schemaTypes: SchemaTypeDefinition[] = [
  // Documents
  post,
  author,
  category,
  
  // Objects
  blockContent,
  seo,
  
  // Singletons
  siteSettings,
]
```

## Document Type Patterns

### Blog Post

```typescript
import { defineField, defineType } from 'sanity'
import { DocumentTextIcon } from '@sanity/icons'

export const post = defineType({
  name: 'post',
  title: 'Post',
  type: 'document',
  icon: DocumentTextIcon,
  
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (Rule) => Rule.required().max(100),
    }),
    
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'title',
        maxLength: 96,
        slugify: (input) => input
          .toLowerCase()
          .replace(/\s+/g, '-')
          .slice(0, 96),
      },
      validation: (Rule) => Rule.required(),
    }),
    
    defineField({
      name: 'excerpt',
      title: 'Excerpt',
      type: 'text',
      rows: 3,
      validation: (Rule) => Rule.max(200),
    }),
    
    defineField({
      name: 'mainImage',
      title: 'Main Image',
      type: 'image',
      options: {
        hotspot: true,
      },
      fields: [
        {
          name: 'alt',
          type: 'string',
          title: 'Alternative Text',
          description: 'Important for SEO and accessibility',
          validation: (Rule) => Rule.required(),
        },
        {
          name: 'caption',
          type: 'string',
          title: 'Caption',
        },
      ],
    }),
    
    defineField({
      name: 'body',
      title: 'Body',
      type: 'blockContent',
    }),
    
    defineField({
      name: 'author',
      title: 'Author',
      type: 'reference',
      to: [{ type: 'author' }],
      validation: (Rule) => Rule.required(),
    }),
    
    defineField({
      name: 'categories',
      title: 'Categories',
      type: 'array',
      of: [{ type: 'reference', to: [{ type: 'category' }] }],
      validation: (Rule) => Rule.max(3),
    }),
    
    defineField({
      name: 'tags',
      title: 'Tags',
      type: 'array',
      of: [{ type: 'string' }],
      options: {
        layout: 'tags',
      },
    }),
    
    defineField({
      name: 'publishedAt',
      title: 'Published At',
      type: 'datetime',
      initialValue: () => new Date().toISOString(),
    }),
    
    defineField({
      name: 'featured',
      title: 'Featured',
      type: 'boolean',
      initialValue: false,
    }),
    
    defineField({
      name: 'seo',
      title: 'SEO',
      type: 'seo',
      description: 'Search engine optimization settings',
    }),
  ],
  
  preview: {
    select: {
      title: 'title',
      author: 'author.name',
      media: 'mainImage',
      publishedAt: 'publishedAt',
    },
    prepare({ title, author, media, publishedAt }) {
      const date = publishedAt ? new Date(publishedAt).toLocaleDateString() : 'No date'
      return {
        title,
        subtitle: author ? `by ${author} · ${date}` : date,
        media,
      }
    },
  },
  
  orderings: [
    {
      title: 'Published Date, New',
      name: 'publishedAtDesc',
      by: [
        { field: 'publishedAt', direction: 'desc' },
        { field: 'title', direction: 'asc' },
      ],
    },
    {
      title: 'Published Date, Old',
      name: 'publishedAtAsc',
      by: [
        { field: 'publishedAt', direction: 'asc' },
        { field: 'title', direction: 'asc' },
      ],
    },
  ],
})
```

### Author

```typescript
import { defineField, defineType } from 'sanity'
import { UserIcon } from '@sanity/icons'

export const author = defineType({
  name: 'author',
  title: 'Author',
  type: 'document',
  icon: UserIcon,
  
  fields: [
    defineField({
      name: 'name',
      title: 'Name',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),
    
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'name',
        maxLength: 96,
      },
      validation: (Rule) => Rule.required(),
    }),
    
    defineField({
      name: 'image',
      title: 'Image',
      type: 'image',
      options: {
        hotspot: true,
      },
      validation: (Rule) => Rule.required(),
    }),
    
    defineField({
      name: 'bio',
      title: 'Bio',
      type: 'array',
      of: [{ type: 'block' }],
    }),
    
    defineField({
      name: 'socialLinks',
      title: 'Social Links',
      type: 'array',
      of: [
        {
          type: 'object',
          fields: [
            {
              name: 'platform',
              type: 'string',
              options: {
                list: [
                  { title: 'Twitter', value: 'twitter' },
                  { title: 'LinkedIn', value: 'linkedin' },
                  { title: 'GitHub', value: 'github' },
                  { title: 'Website', value: 'website' },
                ],
              },
            },
            {
              name: 'url',
              type: 'url',
              validation: (Rule) => Rule.uri({ scheme: ['http', 'https'] }),
            },
          ],
          preview: {
            select: {
              platform: 'platform',
              url: 'url',
            },
            prepare({ platform, url }) {
              return {
                title: platform,
                subtitle: url,
              }
            },
          },
        },
      ],
    }),
  ],
  
  preview: {
    select: {
      title: 'name',
      media: 'image',
    },
  },
})
```

### Category

```typescript
import { defineField, defineType } from 'sanity'
import { TagIcon } from '@sanity/icons'

export const category = defineType({
  name: 'category',
  title: 'Category',
  type: 'document',
  icon: TagIcon,
  
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),
    
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'title',
        maxLength: 96,
      },
      validation: (Rule) => Rule.required(),
    }),
    
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
    }),
    
    defineField({
      name: 'color',
      title: 'Color',
      type: 'string',
      options: {
        list: [
          { title: 'Red', value: '#ef4444' },
          { title: 'Blue', value: '#3b82f6' },
          { title: 'Green', value: '#10b981' },
          { title: 'Purple', value: '#8b5cf6' },
          { title: 'Yellow', value: '#f59e0b' },
        ],
      },
    }),
  ],
  
  preview: {
    select: {
      title: 'title',
      color: 'color',
    },
    prepare({ title, color }) {
      return {
        title,
        media: () => (
          <div
            style={{
              width: '100%',
              height: '100%',
              backgroundColor: color || '#ccc',
            }}
          />
        ),
      }
    },
  },
})
```

## Object Type Patterns

### Block Content (Portable Text)

```typescript
import { defineType, defineArrayMember } from 'sanity'

export const blockContent = defineType({
  title: 'Block Content',
  name: 'blockContent',
  type: 'array',
  of: [
    defineArrayMember({
      title: 'Block',
      type: 'block',
      styles: [
        { title: 'Normal', value: 'normal' },
        { title: 'H2', value: 'h2' },
        { title: 'H3', value: 'h3' },
        { title: 'H4', value: 'h4' },
        { title: 'Quote', value: 'blockquote' },
      ],
      lists: [
        { title: 'Bullet', value: 'bullet' },
        { title: 'Numbered', value: 'number' },
      ],
      marks: {
        decorators: [
          { title: 'Strong', value: 'strong' },
          { title: 'Emphasis', value: 'em' },
          { title: 'Code', value: 'code' },
        ],
        annotations: [
          {
            title: 'URL',
            name: 'link',
            type: 'object',
            fields: [
              {
                title: 'URL',
                name: 'href',
                type: 'url',
                validation: (Rule) => 
                  Rule.uri({ 
                    scheme: ['http', 'https', 'mailto', 'tel'] 
                  }),
              },
              {
                title: 'Open in new tab',
                name: 'blank',
                type: 'boolean',
                initialValue: true,
              },
            ],
          },
          {
            title: 'Internal Link',
            name: 'internalLink',
            type: 'object',
            fields: [
              {
                name: 'reference',
                type: 'reference',
                to: [
                  { type: 'post' },
                  { type: 'page' },
                ],
              },
            ],
          },
        ],
      },
    }),
    
    defineArrayMember({
      type: 'image',
      options: { hotspot: true },
      fields: [
        {
          name: 'alt',
          type: 'string',
          title: 'Alternative Text',
          validation: (Rule) => Rule.required(),
        },
        {
          name: 'caption',
          type: 'string',
          title: 'Caption',
        },
      ],
    }),
    
    defineArrayMember({
      type: 'object',
      name: 'codeBlock',
      title: 'Code Block',
      fields: [
        {
          name: 'code',
          type: 'text',
          title: 'Code',
          rows: 10,
        },
        {
          name: 'language',
          type: 'string',
          title: 'Language',
          options: {
            list: [
              { title: 'JavaScript', value: 'javascript' },
              { title: 'TypeScript', value: 'typescript' },
              { title: 'Python', value: 'python' },
              { title: 'HTML', value: 'html' },
              { title: 'CSS', value: 'css' },
              { title: 'Bash', value: 'bash' },
            ],
          },
        },
        {
          name: 'filename',
          type: 'string',
          title: 'Filename',
        },
      ],
    }),
  ],
})
```

### SEO Object

```typescript
import { defineType, defineField } from 'sanity'

export const seo = defineType({
  name: 'seo',
  title: 'SEO',
  type: 'object',
  fields: [
    defineField({
      name: 'metaTitle',
      title: 'Meta Title',
      type: 'string',
      description: 'Title for search engines (50-60 characters)',
      validation: (Rule) => Rule.max(60),
    }),
    
    defineField({
      name: 'metaDescription',
      title: 'Meta Description',
      type: 'text',
      rows: 3,
      description: 'Description for search engines (150-160 characters)',
      validation: (Rule) => Rule.max(160),
    }),
    
    defineField({
      name: 'ogImage',
      title: 'Open Graph Image',
      type: 'image',
      description: 'Image for social sharing (1200x630px recommended)',
      options: {
        hotspot: true,
      },
    }),
    
    defineField({
      name: 'noIndex',
      title: 'No Index',
      type: 'boolean',
      description: 'Prevent this page from being indexed by search engines',
      initialValue: false,
    }),
  ],
})
```

## Singleton Patterns

### Site Settings

```typescript
import { defineField, defineType } from 'sanity'
import { CogIcon } from '@sanity/icons'

export const siteSettings = defineType({
  name: 'siteSettings',
  title: 'Site Settings',
  type: 'document',
  icon: CogIcon,
  
  // Singleton configuration
  __experimental_actions: ['update', 'publish'],
  
  fields: [
    defineField({
      name: 'title',
      title: 'Site Title',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),
    
    defineField({
      name: 'description',
      title: 'Site Description',
      type: 'text',
      rows: 3,
    }),
    
    defineField({
      name: 'logo',
      title: 'Logo',
      type: 'image',
    }),
    
    defineField({
      name: 'favicon',
      title: 'Favicon',
      type: 'image',
      description: 'Upload a 32x32 or 16x16 pixel favicon',
    }),
    
    defineField({
      name: 'socialLinks',
      title: 'Social Links',
      type: 'object',
      fields: [
        {
          name: 'twitter',
          type: 'url',
          title: 'Twitter',
        },
        {
          name: 'facebook',
          type: 'url',
          title: 'Facebook',
        },
        {
          name: 'instagram',
          type: 'url',
          title: 'Instagram',
        },
      ],
    }),
    
    defineField({
      name: 'analytics',
      title: 'Analytics',
      type: 'object',
      fields: [
        {
          name: 'googleAnalyticsId',
          type: 'string',
          title: 'Google Analytics ID',
        },
      ],
    }),
  ],
  
  preview: {
    prepare() {
      return {
        title: 'Site Settings',
      }
    },
  },
})
```

### Navigation

```typescript
import { defineField, defineType } from 'sanity'
import { MenuIcon } from '@sanity/icons'

export const navigation = defineType({
  name: 'navigation',
  title: 'Navigation',
  type: 'document',
  icon: MenuIcon,
  
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),
    
    defineField({
      name: 'items',
      title: 'Navigation Items',
      type: 'array',
      of: [
        {
          type: 'object',
          fields: [
            {
              name: 'title',
              type: 'string',
              title: 'Title',
            },
            {
              name: 'link',
              type: 'object',
              title: 'Link',
              fields: [
                {
                  name: 'linkType',
                  type: 'string',
                  options: {
                    list: [
                      { title: 'Internal', value: 'internal' },
                      { title: 'External', value: 'external' },
                    ],
                  },
                },
                {
                  name: 'internalLink',
                  type: 'reference',
                  to: [{ type: 'post' }, { type: 'page' }],
                  hidden: ({ parent }) => parent?.linkType !== 'internal',
                },
                {
                  name: 'externalUrl',
                  type: 'url',
                  hidden: ({ parent }) => parent?.linkType !== 'external',
                },
              ],
            },
            {
              name: 'children',
              type: 'array',
              title: 'Submenu Items',
              of: [
                {
                  type: 'object',
                  fields: [
                    { name: 'title', type: 'string' },
                    { name: 'link', type: 'url' },
                  ],
                },
              ],
            },
          ],
          preview: {
            select: {
              title: 'title',
            },
          },
        },
      ],
    }),
  ],
})
```

## Advanced Patterns

### Conditional Fields

```typescript
defineField({
  name: 'eventType',
  title: 'Event Type',
  type: 'string',
  options: {
    list: [
      { title: 'In-Person', value: 'in-person' },
      { title: 'Virtual', value: 'virtual' },
      { title: 'Hybrid', value: 'hybrid' },
    ],
  },
}),

defineField({
  name: 'location',
  title: 'Location',
  type: 'string',
  hidden: ({ parent }) => parent?.eventType === 'virtual',
}),

defineField({
  name: 'virtualLink',
  title: 'Virtual Link',
  type: 'url',
  hidden: ({ parent }) => parent?.eventType === 'in-person',
}),
```

### Validation with Custom Rules

```typescript
defineField({
  name: 'email',
  title: 'Email',
  type: 'string',
  validation: (Rule) =>
    Rule.custom((value) => {
      if (!value) return true
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      return emailRegex.test(value) || 'Please enter a valid email address'
    }),
}),

defineField({
  name: 'price',
  title: 'Price',
  type: 'number',
  validation: (Rule) =>
    Rule.min(0).precision(2).custom((value) => {
      if (value === undefined) return true
      return value >= 0 || 'Price must be a positive number'
    }),
}),
```

### Dynamic Initial Values

```typescript
defineField({
  name: 'publishedAt',
  title: 'Published At',
  type: 'datetime',
  initialValue: () => new Date().toISOString(),
}),

defineField({
  name: 'slug',
  title: 'Slug',
  type: 'slug',
  options: {
    source: (doc) => `${doc.title}-${Date.now()}`,
  },
}),
```

## Best Practices

### 1. Always Use Validation

```typescript
// GOOD
defineField({
  name: 'title',
  type: 'string',
  validation: (Rule) => Rule.required().max(100),
})

// BAD
defineField({
  name: 'title',
  type: 'string',
})
```

### 2. Provide Alt Text for Images

```typescript
// GOOD
defineField({
  name: 'image',
  type: 'image',
  fields: [
    {
      name: 'alt',
      type: 'string',
      validation: (Rule) => Rule.required(),
    },
  ],
})
```

### 3. Use Arrays for Scalability

```typescript
// GOOD - Easier to extend
defineField({
  name: 'authors',
  type: 'array',
  of: [{ type: 'reference', to: [{ type: 'author' }] }],
})

// AVOID - Hard to add more authors later
defineField({
  name: 'author',
  type: 'reference',
  to: [{ type: 'author' }],
})
```

### 4. Prefer Enumerations Over Booleans

```typescript
// GOOD - Extensible
defineField({
  name: 'visibility',
  type: 'string',
  options: {
    list: [
      { title: 'Public', value: 'public' },
      { title: 'Internal', value: 'internal' },
      { title: 'Private', value: 'private' },
    ],
  },
})

// AVOID - Hard to extend
defineField({
  name: 'isPublic',
  type: 'boolean',
})
```

### 5. Add Helpful Descriptions

```typescript
defineField({
  name: 'excerpt',
  title: 'Excerpt',
  type: 'text',
  description: 'Brief summary shown in listings (150-200 characters recommended)',
  validation: (Rule) => Rule.max(200),
})
```

### 6. Configure Preview Properly

```typescript
preview: {
  select: {
    title: 'title',
    subtitle: 'author.name',
    media: 'mainImage',
  },
  prepare({ title, subtitle, media }) {
    return {
      title,
      subtitle: subtitle ? `by ${subtitle}` : 'No author',
      media,
    }
  },
},
```

## Resources

- [Sanity Schema Types](https://www.sanity.io/docs/schema-types)
- [Validation Rules](https://www.sanity.io/docs/validation)
- [Custom Components](https://www.sanity.io/docs/custom-components)
