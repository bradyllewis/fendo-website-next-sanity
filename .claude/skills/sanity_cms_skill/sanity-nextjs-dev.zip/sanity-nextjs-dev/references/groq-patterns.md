# Advanced GROQ Query Patterns

This reference provides advanced GROQ patterns for complex use cases with Sanity.io.

## Complex Filtering

### Multiple Conditions with OR Logic

```groq
// Posts that are either featured OR have more than 100 views
*[_type == "post" && (featured == true || views > 100)]
```

### Date Range Filtering

```groq
// Posts published in the last 30 days
*[_type == "post" && publishedAt > $thirtyDaysAgo && publishedAt <= now()]

// With parameter
*[_type == "post" && publishedAt >= $startDate && publishedAt <= $endDate]
```

### Array Filtering

```groq
// Posts with specific tags
*[_type == "post" && "javascript" in tags]

// Posts with ANY of specified tags
*[_type == "post" && count((tags[])[@ in ["react", "nextjs", "typescript"]]) > 0]

// Posts with ALL specified tags
*[_type == "post" && count((tags[])[@ in $requiredTags]) == count($requiredTags)]
```

### Reference Filtering

```groq
// Posts by specific author
*[_type == "post" && author._ref == $authorId]

// Posts in specific categories
*[_type == "post" && count((categories[]._ref)[@ in $categoryIds]) > 0]

// Posts where author matches criteria
*[_type == "post" && author->name match "John*"]
```

## Advanced Projections

### Conditional Fields

```groq
*[_type == "post"] {
  _id,
  title,
  // Include author only if exists
  author._ref != null => {
    "author": author-> { name, image }
  },
  // Include featured image only if featured
  featured == true => {
    featuredImage
  },
  // Dynamic field based on condition
  views > 1000 => {
    "status": "popular"
  }
}
```

### Computed Fields

```groq
*[_type == "post"] {
  _id,
  title,
  // Word count from portable text
  "wordCount": length(pt::text(body)),
  // Reading time estimate
  "readingTime": round(length(pt::text(body)) / 200),
  // First paragraph
  "excerpt": array::join(string::split(pt::text(body), "\n")[0..1], " "),
  // Full URL
  "url": $baseUrl + "/blog/" + slug.current
}
```

### Nested Reference Expansion

```groq
*[_type == "post"] {
  _id,
  title,
  // Expand author with their posts
  author-> {
    name,
    image,
    "postsCount": count(*[_type == "post" && author._ref == ^._id])
  },
  // Expand categories with their post counts
  categories[]-> {
    title,
    slug,
    "postsCount": count(*[_type == "post" && ^._id in categories[]._ref])
  }
}
```

## Aggregations and Grouping

### Count and Statistics

```groq
{
  "totalPosts": count(*[_type == "post"]),
  "publishedPosts": count(*[_type == "post" && !(_id in path("drafts.**"))]),
  "draftPosts": count(*[_type == "post" && _id in path("drafts.**")]),
  "postsThisMonth": count(*[_type == "post" && publishedAt > $startOfMonth])
}
```

### Group By Pattern

```groq
// Posts grouped by category
*[_type == "category"] {
  _id,
  title,
  "posts": *[_type == "post" && ^._id in categories[]._ref] {
    _id,
    title,
    publishedAt
  }
}

// Posts grouped by year
array::unique(*[_type == "post"].publishedAt[0..3]) {
  "year": @,
  "posts": *[_type == "post" && publishedAt[0..3] == ^.year] | order(publishedAt desc)
}
```

### Top N Pattern

```groq
// Top 5 most viewed posts
*[_type == "post"] | order(views desc) [0...5] {
  _id,
  title,
  views
}

// Top 3 authors by post count
*[_type == "author"] {
  _id,
  name,
  "postsCount": count(*[_type == "post" && author._ref == ^._id])
} | order(postsCount desc) [0...3]
```

## Pagination Patterns

### Offset-Based Pagination

```groq
{
  "posts": *[_type == "post"] | order(publishedAt desc) [$offset...$limit] {
    _id,
    title,
    publishedAt
  },
  "total": count(*[_type == "post"]),
  "hasMore": count(*[_type == "post"]) > $limit
}
```

### Cursor-Based Pagination

```groq
// Using publishedAt as cursor
*[_type == "post" && publishedAt < $cursor] 
| order(publishedAt desc) [0...10] {
  _id,
  title,
  publishedAt,
  // Return cursor for next page
  "cursor": publishedAt
}

// Using _id as cursor
*[_type == "post" && _id > $cursor] 
| order(_id asc) [0...10]
```

### Load More Pattern

```groq
{
  "posts": *[_type == "post"] | order(publishedAt desc) [0...$count] {
    _id,
    title,
    publishedAt
  },
  "nextCursor": *[_type == "post"] | order(publishedAt desc) [$count] {
    "cursor": publishedAt
  }
}
```

## Search Patterns

### Full-Text Search

```groq
// Simple text search
*[_type == "post" && [title, pt::text(body)] match $searchTerm]

// Search with scoring
*[_type == "post"] | score(
  title match $searchTerm,
  pt::text(body) match $searchTerm
) | order(_score desc) {
  _id,
  title,
  _score
}

// Boost title matches
*[_type == "post"] | score(
  boost(title match $searchTerm, 3),
  pt::text(body) match $searchTerm
) | order(_score desc)
```

### Fuzzy Search

```groq
// Case-insensitive partial match
*[_type == "post" && lower(title) match lower("*" + $searchTerm + "*")]

// Multiple field search
*[_type == "post" && 
  (lower(title) match lower("*" + $searchTerm + "*") ||
   lower(pt::text(body)) match lower("*" + $searchTerm + "*"))]
```

### Faceted Search

```groq
{
  "results": *[_type == "post" && 
    ($category == null || $category in categories[]._ref) &&
    ($author == null || author._ref == $author) &&
    ($tag == null || $tag in tags)
  ] [0...20],
  
  "facets": {
    "categories": *[_type == "category"] {
      _id,
      title,
      "count": count(*[_type == "post" && ^._id in categories[]._ref])
    },
    "authors": *[_type == "author"] {
      _id,
      name,
      "count": count(*[_type == "post" && author._ref == ^._id])
    }
  }
}
```

## Performance Optimization

### Using Coalesce for Defaults

```groq
*[_type == "post"] | order(coalesce(publishedAt, _createdAt) desc) {
  _id,
  title,
  "date": coalesce(publishedAt, _createdAt)
}
```

### Efficient Reference Expansion

```groq
// GOOD: Expand only needed fields
*[_type == "post"] {
  _id,
  title,
  author-> { name, image }
}

// AVOID: Expanding entire referenced document
*[_type == "post"] {
  _id,
  title,
  author->
}
```

### Select Pattern for Optional Fields

```groq
*[_type == "post"] {
  _id,
  title,
  "authorName": select(
    defined(author) => author->name,
    "Anonymous"
  ),
  "categoryTitles": select(
    count(categories) > 0 => categories[]->title,
    []
  )
}
```

## Reusable Query Fragments

### Using String Interpolation

```typescript
// Define reusable projections
const postProjection = `{
  _id,
  title,
  slug,
  publishedAt,
  mainImage,
  "author": author-> { name, image }
}`

const categoryProjection = `{
  _id,
  title,
  slug
}`

// Use in queries
const POSTS_QUERY = defineQuery(`
  *[_type == "post"] | order(publishedAt desc) [0...10]
  ${postProjection}
`)

const POST_QUERY = defineQuery(`
  *[_type == "post" && slug.current == $slug][0] ${postProjection}
`)
```

## Advanced Patterns

### Related Content

```groq
*[_type == "post" && slug.current == $slug][0] {
  _id,
  title,
  categories,
  // Related posts by category
  "related": *[_type == "post" && 
    count((categories[]._ref)[@ in ^.categories[]._ref]) > 0 &&
    _id != ^._id
  ] | order(publishedAt desc) [0...3] {
    _id,
    title,
    slug
  }
}
```

### Breadcrumb Trail

```groq
*[_type == "page" && slug.current == $slug][0] {
  _id,
  title,
  // Build breadcrumb trail
  "breadcrumbs": [
    {
      "title": "Home",
      "slug": "/"
    },
    parent-> {
      "title": title,
      "slug": slug.current
    },
    {
      "title": title,
      "slug": slug.current
    }
  ]
}
```

### Hierarchical Content

```groq
// Get page with nested children
*[_type == "page" && slug.current == $slug][0] {
  _id,
  title,
  "children": *[_type == "page" && parent._ref == ^._id] {
    _id,
    title,
    slug,
    "children": *[_type == "page" && parent._ref == ^._id] {
      _id,
      title,
      slug
    }
  }
}
```

### Time-Based Content

```groq
// Content that should be visible now
*[_type == "event" && 
  (!defined(startDate) || startDate <= now()) &&
  (!defined(endDate) || endDate >= now())
] | order(startDate asc)

// Upcoming events
*[_type == "event" && startDate > now()] 
| order(startDate asc)

// Past events
*[_type == "event" && endDate < now()] 
| order(startDate desc)
```

## Testing and Debugging

### Using Vision Tool

The Vision tool in Sanity Studio is invaluable for testing queries:

1. Open Studio at `/studio/vision`
2. Paste your GROQ query
3. Add parameters in the params panel
4. View results and adjust query

### Query Performance Tips

1. **Use indexes**: Order by `_createdAt`, `_updatedAt`, or indexed fields
2. **Limit results**: Always use `[0...n]` for pagination
3. **Avoid deep nesting**: Limit reference depth to 2-3 levels
4. **Use projections**: Only fetch fields you need
5. **Test with production data**: Performance can vary with dataset size

### Common Mistakes to Avoid

```groq
// WRONG: Missing null check
*[_type == "post"] {
  "authorName": author->name  // Fails if author is null
}

// RIGHT: Use select or conditional
*[_type == "post"] {
  "authorName": select(defined(author) => author->name, "Unknown")
}

// WRONG: Inefficient filtering
*[_type == "post"] {
  "isRecent": publishedAt > $thirtyDaysAgo  // Computed for every doc
}

// RIGHT: Filter first
*[_type == "post" && publishedAt > $thirtyDaysAgo] {
  // Fields
}
```

## TypeScript Integration

### Typed Parameters

```typescript
import { defineQuery } from 'next-sanity'

interface PostsQueryParams {
  limit: number
  offset: number
  category?: string
}

export const POSTS_QUERY = defineQuery<PostsQueryParams>(`
  *[_type == "post" && 
    ($category == null || $category in categories[]._ref)
  ] | order(publishedAt desc) [$offset...$limit]
`)
```

### Type-Safe Results

```typescript
import type { POSTS_QUERYResult } from '@/sanity/types'

const posts = await sanityFetch<POSTS_QUERYResult>({
  query: POSTS_QUERY,
  params: { limit: 10, offset: 0 }
})

// TypeScript knows the exact shape of posts
posts.forEach(post => {
  console.log(post.title) // Type-safe!
})
```

## Resources

- [GROQ Cheat Sheet](https://www.sanity.io/docs/query-cheat-sheet)
- [GROQ Arcade](https://groq.dev) - Practice GROQ queries
- [Sanity GROQ Reference](https://www.sanity.io/docs/groq)
- [Query Optimization Guide](https://www.sanity.io/docs/query-performance)
