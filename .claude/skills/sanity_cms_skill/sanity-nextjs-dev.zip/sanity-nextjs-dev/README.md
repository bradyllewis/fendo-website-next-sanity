# Sanity.io Next.js Development Skill

A comprehensive Claude Skill for building production-grade applications with Sanity.io CMS, Next.js 15, TypeScript, and integrated with Supabase, OpenRouter, Vercel AI SDK, and Vercel deployment.

## What This Skill Does

This Skill transforms Claude into an expert Sanity.io + Next.js development assistant that helps you:

- **Set up projects** - Initialize Sanity with Next.js using best practices
- **Design schemas** - Create well-structured, validated content models
- **Write GROQ queries** - Build type-safe queries with automatic TypeScript generation
- **Implement visual editing** - Enable live preview and real-time content updates
- **Integrate services** - Connect Sanity with Supabase, OpenRouter, and Vercel AI SDK
- **Deploy to Vercel** - Configure webhooks and automatic revalidation
- **Optimize performance** - Implement caching, image optimization, and query best practices
- **Troubleshoot issues** - Solve common problems with expert guidance

## Installation

1. Download the `sanity-nextjs-dev.zip` file
2. In Claude.ai, go to Settings → Skills
3. Click "Add Skill" and select "Upload Skill"
4. Choose the downloaded `.zip` file
5. Enable the Skill for your project

## When to Use This Skill

The Skill automatically activates when you:

- Mention "Sanity", "CMS", "headless CMS", or "content management"
- Ask about GROQ queries or TypeScript types
- Need help with Next.js App Router and Sanity integration
- Want to set up visual editing or live preview
- Ask about Vercel deployment or webhooks
- Need to integrate Sanity with Supabase or AI features

## Example Prompts

### Project Setup
```
"Set up a new Next.js 15 project with Sanity CMS, including TypeScript and the App Router"

"Initialize Sanity in my existing Next.js app and configure it for embedded Studio"

"Show me the complete project structure for a Sanity + Next.js application"
```

### Schema Design
```
"Create a Sanity schema for a blog with posts, authors, and categories"

"Design a schema for an e-commerce product with variants and inventory"

"Build a schema for a documentation site with versioned content"
```

### GROQ Queries
```
"Write a GROQ query to fetch the 10 most recent published posts with their authors"

"Create a query that filters posts by category and includes pagination"

"Generate TypeScript types for my GROQ queries using Sanity TypeGen"
```

### Visual Editing & Live Preview
```
"Set up visual editing and live preview for my Next.js app"

"Configure draft mode routes for Sanity Studio"

"Implement the Presentation tool with my Next.js pages"
```

### Integration
```
"Integrate Sanity with Supabase for user-specific content interactions"

"Create an AI chat feature that uses OpenRouter and references Sanity content"

"Build a hybrid data architecture with Sanity for content and Supabase for user data"
```

### Deployment
```
"Configure webhooks to trigger Vercel revalidation when Sanity content updates"

"Set up on-demand revalidation for specific content types"

"Deploy my Sanity + Next.js app to Vercel with proper environment variables"
```

### Optimization & Best Practices
```
"Optimize my Sanity image loading with Next.js Image component"

"Review my GROQ query for performance improvements"

"Set up proper caching strategy for Sanity content in Next.js"
```

## Tech Stack Covered

- **Sanity.io** - Headless CMS with real-time collaboration
- **Next.js 15** - React framework with App Router
- **TypeScript** - Type-safe development throughout
- **GROQ** - Powerful query language for Sanity
- **Sanity TypeGen** - Automatic TypeScript type generation
- **next-sanity** - Official Sanity toolkit for Next.js
- **Supabase** - PostgreSQL database and authentication
- **OpenRouter** - AI model API gateway
- **Vercel AI SDK** - Streaming AI responses
- **Vercel** - Deployment and hosting platform

## What You'll Get

When you ask Claude for help with this Skill, you'll receive:

- **Production-ready code** - Complete, tested implementations
- **TypeScript types** - Fully type-safe code examples
- **Best practices** - Industry-standard patterns and architectures
- **Error handling** - Robust error management built-in
- **Performance optimization** - Efficient queries and caching strategies
- **Integration patterns** - Proven ways to combine technologies
- **Complete examples** - End-to-end implementation guidance

## Key Features

### Automatic Type Generation
The Skill guides you through setting up Sanity TypeGen to automatically generate TypeScript types from your schemas and GROQ queries, eliminating manual type definitions and reducing errors.

### Visual Editing
Learn to implement Sanity's Presentation tool for real-time preview of content changes, giving content editors confidence before publishing.

### Hybrid Architecture
Combine Sanity's powerful content management with Supabase for user data, creating a scalable architecture that leverages the strengths of each platform.

### AI Integration
Connect Sanity content with AI models via OpenRouter and Vercel AI SDK, enabling intelligent features like content-aware chatbots and AI-assisted content creation.

### Deployment Automation
Configure webhooks and on-demand revalidation so your Vercel-hosted site automatically updates when content changes in Sanity Studio.

## Best Practices Enforced

This Skill enforces modern development best practices:

- Schema validation and type safety
- Efficient GROQ query patterns
- Proper image optimization
- Strategic caching and revalidation
- Clean project structure
- Error handling and edge cases
- Accessibility considerations
- Security best practices

## Learning Resources

While using this Skill, you'll naturally learn:

- How Sanity's Content Lake works
- GROQ query language fundamentals
- Next.js App Router patterns
- TypeScript with CMS data
- Serverless architecture
- Real-time preview implementation
- Performance optimization techniques

## Troubleshooting Common Issues

The Skill includes expert guidance on:

- TypeGen not generating types
- Visual editing/preview not working
- Images not loading properly
- Webhook issues
- CORS configuration
- Environment variable setup
- Type inference problems

## Version Compatibility

This Skill is designed for:

- Sanity v3+
- Next.js 15+
- React 18+
- TypeScript 5+
- Node.js 18+

## Tips for Best Results

1. **Be specific** - Mention the exact feature you're implementing
2. **Provide context** - Share relevant schema types or queries when asking for help
3. **Ask follow-ups** - Request explanations of best practices or alternative approaches
4. **Share errors** - Include error messages for faster troubleshooting

## Example Workflows

### Starting a New Project
1. "Set up a new Next.js 15 project with Sanity"
2. "Create a blog schema with posts, authors, and categories"
3. "Write GROQ queries for fetching posts"
4. "Set up visual editing"
5. "Configure Vercel deployment with webhooks"

### Adding Features
1. "Add a search feature using GROQ"
2. "Implement pagination for my blog posts"
3. "Create an AI chatbot that references my Sanity content"
4. "Add user bookmarking with Supabase"

### Optimization
1. "Review my GROQ queries for performance"
2. "Optimize my image loading strategy"
3. "Set up proper caching for my content"
4. "Improve my schema design"

## Support and Updates

This Skill is maintained to stay current with:

- Latest Sanity features and best practices
- Next.js updates and new capabilities
- Vercel platform enhancements
- Community-discovered patterns

## License

Apache-2.0

## Feedback

If you encounter issues or have suggestions for improving this Skill, use the thumbs down button on Claude's responses to provide feedback to Anthropic.

---

**Ready to build amazing content-driven applications with Sanity and Next.js!**
