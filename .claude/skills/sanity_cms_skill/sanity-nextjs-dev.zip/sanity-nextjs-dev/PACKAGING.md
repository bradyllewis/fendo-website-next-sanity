# Packaging Instructions

## Creating the Skill Package

To package this Skill for distribution, follow these steps:

### 1. Verify File Structure

Ensure you have the following structure:

```
sanity-nextjs-dev/
├── SKILL.md                          # Main skill file (REQUIRED)
├── README.md                         # User documentation
└── references/                       # Reference documentation
    ├── groq-patterns.md             # Advanced GROQ patterns
    └── schema-patterns.md           # Schema design patterns
```

### 2. Create the ZIP File

**From the command line:**

```bash
# Navigate to the parent directory
cd /path/to/parent

# Create the ZIP file
zip -r sanity-nextjs-dev.zip sanity-nextjs-dev/
```

**From macOS Finder:**
1. Right-click on the `sanity-nextjs-dev` folder
2. Select "Compress sanity-nextjs-dev"
3. Rename the resulting file to `sanity-nextjs-dev.zip`

**From Windows Explorer:**
1. Right-click on the `sanity-nextjs-dev` folder
2. Select "Send to" → "Compressed (zipped) folder"
3. Rename to `sanity-nextjs-dev.zip`

### 3. Verify the Package

Extract the ZIP to a temporary location and verify:

- [ ] SKILL.md is present and properly formatted
- [ ] Frontmatter has correct name and description
- [ ] README.md is included
- [ ] All reference files are in the references/ directory
- [ ] No extra files (like .DS_Store or node_modules)

### 4. Test the Skill

1. Upload to Claude.ai via Settings → Skills
2. Enable the Skill
3. Test with example prompts:
   - "Set up a new Sanity project with Next.js"
   - "Create a blog schema for Sanity"
   - "Write a GROQ query to fetch recent posts"

## File Descriptions

### SKILL.md
The main skill file that contains all instructions Claude needs. This file:
- Must be named exactly `SKILL.md` (case-sensitive)
- Contains YAML frontmatter with name and description
- Includes all core instructions and patterns
- Is the only required file

### README.md
User-facing documentation that explains:
- What the Skill does
- How to install it
- Example prompts to trigger it
- Expected outcomes

### references/
Additional reference documentation that Claude can load when needed:
- **groq-patterns.md** - Advanced GROQ query patterns
- **schema-patterns.md** - Comprehensive schema design patterns

These files are loaded conditionally based on the task.

## Sharing the Skill

Once packaged, you can share the `sanity-nextjs-dev.zip` file:

1. **Direct Distribution**: Share the ZIP file directly
2. **GitHub Release**: Upload as a release asset
3. **Documentation Site**: Host and provide download link

## Updating the Skill

To update the Skill:

1. Modify the relevant files
2. Update version information if tracking versions
3. Re-package following steps above
4. Users must re-upload the updated ZIP

## Version History

### v1.0.0 (Initial Release)
- Complete Sanity.io + Next.js development toolkit
- Support for Next.js 15 App Router
- TypeScript type generation with Sanity TypeGen
- Visual editing and live preview setup
- Integration patterns for Supabase, OpenRouter, Vercel AI SDK
- Comprehensive GROQ query patterns
- Schema design best practices
- Vercel deployment and webhook configuration

## License

Apache-2.0
