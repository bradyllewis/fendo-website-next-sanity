# Test Prompts for Sanity Next.js Development Skill

Use these prompts to verify the Skill is working correctly and to understand its capabilities.

## Setup and Configuration

### Test 1: Initial Project Setup
**Prompt:**
```
Set up a new Next.js 15 project with Sanity CMS integration. Include TypeScript, Tailwind CSS, and configure it for the App Router with an embedded Studio at /studio.
```

**Expected Output:**
- Complete setup commands
- Environment variable configuration
- Project structure explanation
- Client configuration code
- Studio setup code

### Test 2: Environment Variables
**Prompt:**
```
What environment variables do I need for a Sanity + Next.js project that also uses Supabase and OpenRouter?
```

**Expected Output:**
- Complete .env.local file template
- Explanation of each variable
- Where to find/generate each value
- Public vs. private variable guidance

## Schema Design

### Test 3: Blog Schema
**Prompt:**
```
Create a complete blog schema for Sanity including posts, authors, and categories. Include proper validation and preview configuration.
```

**Expected Output:**
- Three schema files (post, author, category)
- Validation rules on all fields
- Preview configurations
- Relationships properly set up
- Best practices followed

### Test 4: E-commerce Schema
**Prompt:**
```
Design a Sanity schema for an e-commerce store with products, variants, and inventory tracking.
```

**Expected Output:**
- Product schema with variants
- Inventory management fields
- Image galleries
- Pricing structure
- Category/tag references

### Test 5: Custom Block Content
**Prompt:**
```
Create a custom block content type for Sanity that supports headings, lists, links, images, code blocks, and custom call-out boxes.
```

**Expected Output:**
- Complete blockContent schema
- Custom annotations
- Custom block types
- Proper configuration

## GROQ Queries

### Test 6: Basic Query
**Prompt:**
```
Write a GROQ query to fetch the 10 most recent published blog posts with their titles, slugs, publish dates, main images, and author names.
```

**Expected Output:**
- Properly formatted GROQ query
- Use of defineQuery
- Type-safe parameter structure
- Efficient projection

### Test 7: Advanced Filtering
**Prompt:**
```
Create a GROQ query that fetches posts filtered by category, with pagination, and includes related posts based on shared tags.
```

**Expected Output:**
- Complex filtering logic
- Pagination implementation
- Related content logic
- Type-safe parameters

### Test 8: Search Query
**Prompt:**
```
Build a GROQ query for full-text search across post titles and body content with relevance scoring.
```

**Expected Output:**
- Search implementation
- Scoring logic
- Match operators
- Sorted results

## Visual Editing & Live Preview

### Test 9: Draft Mode Setup
**Prompt:**
```
Set up draft mode and live preview for my Next.js app so content editors can see changes in real-time.
```

**Expected Output:**
- Draft mode API routes
- Client configuration with stega
- Live setup with defineLive
- Layout modifications
- Presentation tool config

### Test 10: Visual Editing Component
**Prompt:**
```
Show me how to create a blog post page that supports visual editing and automatically updates when content changes in Sanity Studio.
```

**Expected Output:**
- Page component with sanityFetch
- Draft mode integration
- Live preview setup
- Proper TypeScript types

## Integration Patterns

### Test 11: Supabase Integration
**Prompt:**
```
How do I combine Sanity content with Supabase user data? Show me an example of a blog post with user-specific interactions like likes and bookmarks.
```

**Expected Output:**
- Hybrid data pattern
- Supabase client setup
- Combined query example
- Type-safe implementation

### Test 12: AI Chat with Context
**Prompt:**
```
Create an AI chat feature using OpenRouter and Vercel AI SDK that has context about a specific Sanity blog post.
```

**Expected Output:**
- API route with streaming
- OpenRouter configuration
- Sanity content integration
- Client component with useChat

### Test 13: Full Stack Integration
**Prompt:**
```
Build a feature where users can ask questions about a blog post using AI, and their questions are saved to Supabase for analytics.
```

**Expected Output:**
- Complete implementation
- Sanity query for content
- OpenRouter API integration
- Supabase data persistence
- Type-safe throughout

## Deployment & Webhooks

### Test 14: Vercel Deployment
**Prompt:**
```
Configure my Sanity + Next.js app for Vercel deployment with automatic revalidation when content changes.
```

**Expected Output:**
- Deployment instructions
- Webhook handler code
- Vercel configuration
- Sanity webhook setup
- Environment variables

### Test 15: Revalidation Strategy
**Prompt:**
```
Set up on-demand revalidation with cache tags so only affected pages rebuild when content updates.
```

**Expected Output:**
- Cache tag implementation
- Webhook handler with tags
- sanityFetch with tags
- Revalidation logic

## Performance Optimization

### Test 16: Image Optimization
**Prompt:**
```
Create a reusable Sanity image component for Next.js with automatic optimization, blur placeholders, and responsive sizing.
```

**Expected Output:**
- Complete component code
- Next.js Image integration
- Sanity image URL builder
- Blur placeholder generation
- TypeScript types

### Test 17: Query Optimization
**Prompt:**
```
Review this GROQ query and optimize it for performance: [provide inefficient query]
```

**Expected Output:**
- Analysis of issues
- Optimized query
- Explanation of improvements
- Best practices reminder

## Troubleshooting

### Test 18: TypeGen Issues
**Prompt:**
```
My Sanity TypeGen isn't generating types for my GROQ queries. What could be wrong?
```

**Expected Output:**
- Troubleshooting checklist
- Common causes
- Step-by-step fixes
- Verification steps

### Test 19: Preview Not Working
**Prompt:**
```
Visual editing and live preview aren't working in my app. Help me debug this.
```

**Expected Output:**
- Systematic debugging approach
- Check CORS settings
- Verify tokens
- Check stega configuration
- Validate routes

### Test 20: General Architecture
**Prompt:**
```
I'm building a content-heavy site with user accounts. Should I use Sanity for everything or combine it with Supabase?
```

**Expected Output:**
- Architecture recommendations
- Sanity strengths (content)
- Supabase strengths (user data)
- Hybrid approach explanation
- Example implementation

## Advanced Patterns

### Test 21: Internationalization
**Prompt:**
```
How do I add multi-language support to my Sanity schemas and GROQ queries?
```

**Expected Output:**
- Schema patterns for i18n
- GROQ query modifications
- Language filtering
- Best practices

### Test 22: Content Versioning
**Prompt:**
```
Set up content versioning so editors can work on drafts without affecting published content.
```

**Expected Output:**
- Draft vs. published explanation
- Query perspective usage
- Workflow recommendations
- Presentation tool integration

### Test 23: Complex Relationships
**Prompt:**
```
Design a schema where posts can have multiple authors, each with different contribution types (writer, editor, photographer).
```

**Expected Output:**
- Advanced schema design
- Array of objects pattern
- Reference handling
- GROQ query examples

## Real-World Scenarios

### Test 24: Blog Platform
**Prompt:**
```
I'm building a multi-author blog platform. Walk me through the complete setup from schema design to deployment.
```

**Expected Output:**
- Complete architecture
- Schema files
- GROQ queries
- UI components
- Deployment guide

### Test 25: Documentation Site
**Prompt:**
```
Create schemas and queries for a documentation site with versioned content, code examples, and search.
```

**Expected Output:**
- Documentation-specific schemas
- Version handling
- Search implementation
- Code block patterns
- Navigation structure

## Validation Criteria

When testing, verify that Claude:

1. **Provides complete code** - No placeholders or "add your code here"
2. **Uses TypeScript** - All code is type-safe
3. **Follows best practices** - Matches patterns in the Skill
4. **Includes error handling** - Robust implementations
5. **Uses latest features** - Next.js 15, Sanity v3+
6. **Explains when needed** - Brief but clear explanations
7. **Stays current** - Uses 2024/2025 best practices
8. **Is production-ready** - Code can be used as-is

## Success Metrics

The Skill is working well if:

- Responses are detailed and actionable
- Code examples are complete and runnable
- TypeScript types are properly generated
- Best practices are consistently applied
- Integration patterns work seamlessly
- Troubleshooting is systematic
- Explanations are clear but concise

## Failure Indicators

Report issues if:

- Code has placeholders or TODOs
- TypeScript types are missing or wrong
- Deprecated patterns are suggested
- Best practices are violated
- Integration examples don't work together
- Explanations are overly verbose
- Latest features aren't used
